from flask import Flask, render_template, request, send_from_directory
import numpy as np
from PIL import Image
import time
import os
import warnings
warnings.filterwarnings("ignore")

os.makedirs("outputs", exist_ok=True)

app = Flask(__name__) 

methods = {
    "Mean": "mean",
    "Max": "max",
    "Percentile": "perc",
}

method_id = "Mean"

def divide_image(image: np.ndarray) -> list[np.ndarray]:
    mx, my = image.shape[0] // 2, image.shape[1] // 2
    return [image[:mx, :my],
            image[:mx, my:],
            image[mx:, :my],
            image[mx:, my:]]

def construct_image(divided: list[np.ndarray]) -> np.ndarray:
    return np.vstack([np.hstack(divided[:2]),
                      np.hstack(divided[2:])])

def avg_color(image: np.ndarray):
    return np.mean(image, axis=(0, 1)).astype(np.uint8)

def loss_image(image: np.ndarray, avg):
    return (np.abs(image.astype(np.int16) - avg).astype(np.uint8))

def max_color(image: np.ndarray):
    return np.max(image, axis=(0, 1)).astype(np.uint8)

def perc_color(image: np.ndarray, perc: float):
    return np.mean(np.percentile(image, perc, axis=(0, 1))).astype(np.uint8)

def QuadTree(image: np.ndarray, threshold: int):
    if min(image.shape) < 2:
        return image
    avg = avg_color(image)
    if np.mean(avg_color(loss_image(image, avg))) < threshold:
        return np.full_like(image, avg)
    return construct_image([QuadTree(divided, threshold) for divided in divide_image(image)])

def QuadTree_max(image: np.ndarray, threshold: float):
    if min(image.shape) < 2:
        return image
    avg = avg_color(image)
    if np.mean(max_color(loss_image(image, avg))) < threshold:
        return np.full_like(image, avg)
    return construct_image([QuadTree_max(divided, threshold) for divided in divide_image(image)])

def QuadTree_perc(image: np.ndarray, threshold: float, perc: float):
    if min(image.shape) < 2:
        return image
    avg = avg_color(image)
    if np.mean(perc_color(loss_image(image, avg), perc)) < threshold:
        return np.full_like(image, avg)
    return construct_image([QuadTree_perc(divided, threshold, perc) for divided in divide_image(image)])

@app.route('/')
def index():
    return render_template('index.html', available_models=methods.keys())

@app.route('/upload', methods=['POST'])
def upload():
    if 'image' not in request.files:
        return render_template('index.html', error='No image file')

    file = request.files['image']
    threshold = int(request.form['threshold'])
    method = request.form['method']
    perc = None
    if method == 'perc':
        perc = float(request.form['percentile'])

    if file.filename == '':
        return render_template('index.html', error='No selected image file')

    old_file_path = os.path.join("outputs", "compressed.png")
    if os.path.exists(old_file_path):
        os.remove(old_file_path)
        print("Old file removed")
        
    compressed_img = process_image(file, method, threshold, perc)
    
    print("---\n\nCompressed image saved as compressed.png \n\n---")
 
    return render_template('index.html', result=compressed_img)

@app.route('/select_model', methods=['POST'])
def select_model():
    method_id = request.form.get('model_select')
    method = methods[method_id]
    return render_template('index.html', available_models=methods.keys(), selected_method=method)

@app.route('/outputs/<filename>')
def uploaded_file(filename):
    return send_from_directory("outputs", filename)

def process_image(file, method, threshold, perc=None):
    print(f"---\n\nProcessing image {file.filename}\n\n---")
    
    img = Image.open(file)
    img = img.convert('RGB')

    start = time.time()

    if method == "mean" or method not in ["mean", "max", "perc"]:
        result = QuadTree(np.array(img), threshold)
    
    elif method == "max":
        result = QuadTree_max(np.array(img), threshold)
        
    elif method == "perc":
        result = QuadTree_perc(np.array(img), threshold, perc)
    
    print(f"---\n\nCompressed image\n\n---")
    print(f"---\n\nTime to process image: {round(time.time() - start, 2)} seconds\n\n---")
    result_img = Image.fromarray(result.astype(np.uint8))
    result_img.save(os.path.join("outputs", "compressed.png"))
    return result_img

if __name__ == '__main__':
    app.run(debug=True)
